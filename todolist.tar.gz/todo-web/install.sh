BB#!/bin/bash

# DEBUT DU SCRIPT
echo "Demarrage du script"
echo "clonage dans le Dossier courant :"
git clone https://Scytys:moliku31@bitbucket.org/ynov-b2/todo-web.git &> /dev/null
if $? != 0
then
    echo "Un problème est survenu sur git, avez vous les permissions ?"
fi
