$(document).ready(function () {
    $(document).scroll(() => {
        var $header = $('header');
        
        if ($(this).scrollTop() > 20) {
            if (!$header.hasClass('shadow'))
                $header.addClass('shadow');
        }
        else if ($header.hasClass('shadow'))
            $header.removeClass('shadow');

    });

    $(".popup.view").click(function (e) {
        e.stopPropagation();
    });
    $(".popup.container, #closePopupButton").click(function () {
        hidePopup();
    });

    $("#addTaskButton").click(showPopup);

    $('#taskNameInput').keyup((e) => {
        if (e.keyCode == 13)
            addTask();
    });

    $('#addButton').click(addTask);

    $(document).on('click', '.task .zmdi-delete',removeTask);
});

// Popup
function showPopup() {
    $('.popup.container').fadeIn(100);
    $('#taskNameInput').focus();
}

function hidePopup(clearInput) {
    $('.popup.container').fadeOut(200, function () {
        if (clearInput)
            $('#taskNameInput').val('');
    });
}

// Event Handlers
function onTaskAdded(task) {
    hidePopup(true);
    $(task).prependTo('#taskList').hide().slideDown(200);
}

function onTaskRemoved(taskId) {
    $('#' + taskId).slideUp(200, () => {
        $(this).remove();
    });
}

// API REST - Gestion des tâches
function addTask() {
    let task = {
        name: $('#taskNameInput').val()
    };

    // Ajout d'une tâche en appellant cette page en REST avec PUT.
    // data:    Récupère l'id de la tâche qui est dans l'attribut 'id' de la div parent.
    // success: Supprimer la tâche du DOM.
    $.ajax({
        url: '/dashboard',
        method: 'PUT',
        data: task,
        success: onTaskAdded,
        error: function (err) {
            console.log(err);
        }
    });
}

function removeTask() {
    // Suppression d'une tâche en appellant cette page en REST avec DELETE.
    // data:    Récupère l'id de la tâche qui est dans l'attribut 'id' de la div parent.
    // success: Supprimer la tâche du DOM.
    $.ajax({
        url: '/dashboard',
        method: 'DELETE',
        data: { taskId: $(this).closest(".task").attr('id') },
        success: (id) => {
            onTaskRemoved(id)
        },
        error: function (err) {
            console.log(err);
        }
    });
}